//background.js
//This file will monitor URL changes. It also connects with the 
//firebase database to receive and format user information, more 
//specifically, their login credentials and flagged websites visited.
//(Flagged websites are websites specified to be monitored by the parents).
(function(){
// Your web app's Firebase configuration
  var firebaseConfig = {
       apiKey: "AIzaSyCbI8uEoiGR8X9TuvjU2nFZz8Fjl07kt18",
       authDomain: "screenaware.firebaseapp.com",
       databaseURL: "https://screenaware.firebaseio.com",
       projectId: "screenaware",
       storageBucket: "screenaware.appspot.com",
       messagingSenderId: "48486854475",
       appId: "1:48486854475:web:10ab88fae6f3d78e11c2ce"
     };
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
console.log(firebase);

var tabToUrl = {};
var d1;
var today;
//var today;
chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
    // Note: this event is fired twice:
    // Once with `changeInfo.status` = "loading" and another time with "complete"
    tabToUrl[tabId] = tab.url;  
    if (changeInfo.status == 'complete' && tab.active) {

     
      var user = firebase.auth().currentUser;
      var url = " ";
      console.log("We in!");
      if(user) {
         //user signed in got the url and we check!
         url = user.photoURL;
         console.log(url);
         console.log("here");
         if(url == tab.url){
            console.log("caught u!");
            d1 = Date.now();
            today = new Date();
            var dd = today.getDate();
            var mm = today.getMonth()+1; 
            var yyyy = today.getFullYear();
            var hh = today.getHours();
            var min = today.getMinutes();
            if(dd<10) 
            {
               dd='0'+dd;
            } 

            if(mm<10) 
            {
               mm='0'+mm;
            } 
            if(hh<10)
            {
               hh = '0'+hh;
            }if(min < 10)
            {
               min = '0'+min;
            }
            today = mm+'-'+dd+'-'+yyyy+' '+hh+':'+min;
            
            console.log(today);
            
         }
      }else{
         //No user signed in
         console.log("we out!"); 
      }
  
    }
});

chrome.tabs.onActivated.addListener(function(activeInfo) {
   // how to fetch tab url using activeInfo.tabid
   chrome.tabs.get(activeInfo.tabId, function(tab){
      console.log("here");
      console.log(tab.url);
      var user = firebase.auth().currentUser;
      var url = " ";
      console.log("We in!");
      //check if the user has logged in.
      if(user) {
         //user signed in got the url and we check!
         url = user.photoURL;
         console.log(url);
         console.log("here");
         if(url == tab.url){
            console.log("caught u!");
            d1 = Date.now();
            today = new Date();
            var dd = today.getDate();
            var mm = today.getMonth()+1; 
            var yyyy = today.getFullYear();
            var hh = today.getHours();
            var min = today.getMinutes();
            if(dd<10) 
            {
               dd='0'+dd;
            } 

            if(mm<10) 
            {
               mm='0'+mm;
            } 
            if(hh<10)
            {
               hh = '0'+hh;
            }if(min < 10)
            {
               min = '0'+min;
            }
            today = mm+'-'+dd+'-'+yyyy+' '+hh+':'+min;
            //alert("today!");
            console.log(today);
            //writeNewPost(user.uid, user.email, user.photoURL, today);
         }
      }else{
         //No user signed in
         console.log("we out!"); 
      }
   });
 });

 chrome.runtime.onMessage.addListener((msg, sender, response)=>{
   console.log(msg.command);

   if(msg.command == 'logoutAuth'){
      firebase.auth().signOut().then(function(){
         //Sign out successfull
         
         response({type: "un-auth", status: "success", message: true});
      }, function(error){
         //An error ocurred
         response({type:"un-auth", status: "false", message: error});
      });  
   }

   if(msg.command == 'checkAuth'){
      var user = firebase.auth().currentUser;
      console.log(user);
      if(user) {
         //user signed in
         response({type: "auth", status: "success", message: user});
      }else{
         //No user signed in
         
         response({type: "auth", status: "no-auth", message: false});
      }
   }
   if(msg.command == 'loginUser'){
      console.log(msg.data);
      var email = msg.data.e;
      var pass = msg.data.p;

      firebase.auth().signInWithEmailAndPassword(email, pass).catch(function(error){
         //Handle errors here
         var errorCode = error.code;
         var errorMessage = error.message;
         console.log(error);
         
         response({type: "auth", status: "error", message: error});
      });
      firebase.auth().onAuthStateChanged(function(user){
         if(user){
            //signed in 
            console.log(user);
            
            
            response({type: "auth", status: "success", message: user});
         } else {
            //No user signed in (handled this condition in the firebase auth catch excpetion)
            
            response({type: "auth", status: "error", message: false});
         }
      });
   }
});
//create a new node in the firebase database
function writeNewPost(uid, email, url, timestap, date) {
   // A post entry.
   var postData = {
     email: email,
     uid: uid,
     url: url,
     time: timestap,
     date: date
   };
 
   // Get a key for a new Post.
   var newPostKey = firebase.database().ref().child('posts').push().key;
 
   // Write the new post's data simultaneously in the posts list and the user's post list.
   var updates = {};
   updates['/posts/' + newPostKey] = postData;
   updates['/user-posts/' + uid + '/' + newPostKey] = postData;
 
   return firebase.database().ref().update(updates);
 }
//check for the tabs being closed and if it's the tab you have been monitoring
 chrome.tabs.onRemoved.addListener(function(tabid, removed) {
   
   var user = firebase.auth().currentUser;
   if(user) {
      if(user.photoURL == tabToUrl[tabid]){
         var d2 = Date.now();
         var diff = ((d2 - d1)/1000);
         if(isNaN(diff)){
            diff = -1;
         }
         if(isNaN(today)){
            var date= new Date();
            var dd = date.getDate();
            var mm = date.getMonth()+1; 
            var yyyy = date.getFullYear();
            var hh = date.getHours();
            var min = date.getMinutes();
            if(dd<10) 
            {
               dd='0'+dd;
            } 

            if(mm<10) 
            {
               mm='0'+mm;
            } 
            if(hh<10)
            {
               hh = '0'+hh;
            }if(min < 10)
            {
               min = '0'+min;
            }
            today = mm+'-'+dd+'-'+yyyy+' '+hh+':'+min;
         }
         writeNewPost(user.uid, user.email, user.photoURL, diff, today);
      }
   }


  });

}());